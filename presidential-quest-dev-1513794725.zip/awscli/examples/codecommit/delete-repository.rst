**To delete a repository**

This example shows how to delete an AWS CodeCommit repository.

Command::

  aws codecommit delete-repository --repository-name MyDemoRepo

Output::

  {
    "repositoryId": "f7579e13-b83e-4027-aaef-650c0EXAMPLE"
  }