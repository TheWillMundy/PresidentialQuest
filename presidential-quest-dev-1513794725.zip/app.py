from flask import Flask, render_template, request, redirect
from flask_ask import Ask, statement, question, session
from fuzzywuzzy import fuzz, process
import json
# import requests
# import time
# import unidecode

# Dynamo Connect
import dynamo_connect as db_connect
# Quest Helper Functions
import quest_helpers

app = Flask(__name__)
ask = Ask(app, "/presidential_facts")

# Helper Functions
def get_challenge():
    random_president = quest_helpers.random_president()
    random_fact = db_connect.get_facts(random_president)
    return random_president, random_fact
    
def score_review(score, spoken_president, actual_president):
    if match_spoken_president == actual_president:
        score['player'] += 1
    else:
        score['villain'] += 1
    if score['player'] == score['villain']:
        in_the_lead = "a tie!"
    else:
        score['player'] > score['villain'] ? (in_the_lead = "looks like you're winning!") : (in_the_lead = "oh no, {} is winning. You need to catch up!")
    review_score_message = "Nice! You were correct, the answer was {}. The score is currently {} to {} - {}".format(actual_president, score['player'], score['villain'], in_the_lead)
    return score, review_score_message

def limit_reached(score, villain):
    if score['player'] >= 3:
        return render_template('player_victory', villain=villain, name=name)
    elif score['villain'] >= 3:
        return render_template('villain_victory', villain=villain, name=name)
    else:
        return False

@app.route('/')
def homepage():
    return 'Greetings, this is an Alexa Skill for Heroes of the Storm. Now shoo, let the Alexa users have their turn.'

@app.route('/fact_form', methods=['GET'])
def fact_form():
    return render_template('form.html')

@app.route('/add_fact', methods=['POST'])
def add():
    result = request.form
    db_connect.add_facts(result['president'], result['fact'])      
    return redirect('/fact_form')

@ask.launch
def start_skill():
    user_id = session.user.user_id
    # Search for user in DB
    name = db_connect.check_user(user_id)
    if name == "DNE":
        message = "<speak>Hello! The White House is very pleased to meet you. What is your name?</speak>"
    else:
        session['name'] = name
        message = "<speak>Welcome back, {}! The White House is excited to see you again. Do you wish to begin?</speak>".format(name)
    return question(message)

@ask.intent("PresidentialIntent", default={'name': 'Player'})
def presidential_intent(name):
    if 'name' in session:
        name = session['name']
    random_villain, villain_backstory = quest_helpers.random_villain()
    # Setup Session
    session['villain'] = random_villain
    session['villain_backstory'] = villain_backstory
    # Setup Challenge
    random_president, random_fact = get_challenge()
    session['president'] = random_president
    message = render_template('introduction', villain=random_villain, villain_backstory=villain_backstory, name=name, random_fact=random_fact)
    return question(message)

@ask.intent("QuestStepIntent")
def quest_step_intent(spoken_president):
    # Ensures correct intent being executed
    if 'president' not in session:
        return presidential_intent('Player')
    match_spoken_president = process.extractOne(spoken_president, db_connect.get_presidents())
    actual_president = session['president']
    # Setup score
    score = {'player': 0, 'villain': 0}
    if 'score' in session:
        score = session['score']
    score, score_review_msg = score_review(score, match_spoken_president, actual_president)
    # Check score
    message = limit_reached(score)
    if not message:
        return statement(message)
    # Next challenge
    random_president, random_fact = get_challenge()
    session['president'] = random_president
    message = render_template('quest_step', villain=session['villain'], score_review=score_review_msg, random_fact=random_fact)
    return question(message)

@ask.intent("AMAZON.HelpIntent")
def help_intent():
    help_text = '<speak></speak>'
    return question(help_text)

@ask.intent("AMAZON.CancelIntent")
def cancel_intent():
    print("User canceled the interaction")
    return statement('')

@ask.intent("AMAZON.StopIntent")
def stop_intent():
    print("User canceled the interaction")
    return statement('')

if __name__ == '__main__':
    app.run(debug=True)
